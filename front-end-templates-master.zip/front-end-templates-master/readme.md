## Basic News Package Templates

This repo contains several front-end HTML templates for Intro Coding.

Click on a folder to see more info about each template. Examples can be [viewed here](https://jrue.github.io/front-end-templates/). Work in progress, the Easter Island is still a little buggy.
